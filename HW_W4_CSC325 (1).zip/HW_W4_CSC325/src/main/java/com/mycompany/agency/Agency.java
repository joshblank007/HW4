package com.mycompany.agency;

//Osmany 09/22/2023

public class Agency
{
    //-----------------------------------------------------------------
    //  Creates a staff of employees for a agency and pays them.
    //-----------------------------------------------------------------
    public static void main(String[] args)
    {
        Staff personnel = new Staff();

        personnel.payday();
    }
}
